"""
Simple Visualization: Original Slice vs Predicted vs Ground Truth

Shows a clean 3-panel comparison for aneurysm cases.

Usage:
    python visualize_simple.py --predictions_dir outputs/fusion_YYYYMMDD_HHMMSS
    python visualize_simple.py --predictions_dir outputs/fusion_YYYYMMDD_HHMMSS --top_n 20
"""

import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).parent))
from config.config import Config


def load_original_volume(series_uid, modality, base_dirs):
    """Load the original preprocessed volume"""
    for label_dir in ['aneurysm', 'no_aneurysm']:
        for mod_name in ['CTA', 'MRA', 'MRI']:
            if modality.upper().startswith(mod_name):
                base_dir = base_dirs[mod_name]
                file_path = os.path.join(base_dir, label_dir, f"{series_uid}.npy")
                if os.path.exists(file_path):
                    volume = np.load(file_path)  # Shape: (256, 256, 7)
                    return volume, mod_name, label_dir
    return None, None, None


def load_ground_truth_mask(series_uid, modality, config):
    """Load ground truth segmentation mask if available"""
    import nibabel as nib
    from scipy.ndimage import zoom
    
    # Check segmentation directory
    seg_dir = config.data.segmentation_masks_dir
    if not os.path.exists(seg_dir):
        return None
    
    # Try _cowseg version first (preprocessed segmentation)
    patterns = [
        f"{series_uid}_cowseg.nii",
        f"{series_uid}_cowseg.nii.gz",
        f"{series_uid}.nii",
        f"{series_uid}.nii.gz"
    ]
    
    for pattern in patterns:
        mask_path = os.path.join(seg_dir, pattern)
        if os.path.exists(mask_path):
            try:
                # Load NIfTI file
                nii_img = nib.load(mask_path)
                mask_3d = nii_img.get_fdata()  # Shape: (H, W, D) or (H, W)
                
                # Handle 3D masks
                if mask_3d.ndim == 3:
                    # Find slice with maximum mask area (likely the best slice)
                    slice_sums = [mask_3d[:, :, i].sum() for i in range(mask_3d.shape[2])]
                    if max(slice_sums) == 0:
                        # No mask data
                        return None
                    best_slice_idx = np.argmax(slice_sums)
                    mask_2d = mask_3d[:, :, best_slice_idx]
                else:
                    mask_2d = mask_3d
                
                # Check if mask is empty
                if mask_2d.sum() == 0:
                    return None
                
                # Resize to 256x256 if needed
                if mask_2d.shape != (256, 256):
                    zoom_factors = (256 / mask_2d.shape[0], 256 / mask_2d.shape[1])
                    mask_2d = zoom(mask_2d, zoom_factors, order=1)
                
                # Normalize and threshold
                mask_2d = mask_2d / mask_2d.max() if mask_2d.max() > 0 else mask_2d
                mask_2d = (mask_2d > 0.5).astype(np.float32)
                
                # Only return if mask has actual content
                if mask_2d.sum() > 0:
                    return mask_2d
                    
            except Exception as e:
                continue
    
    return None


def visualize_comparison(series_uid, row, predictions_data, base_dirs, config, save_path=None):
    """Show simple 3-panel comparison: Original | Predicted | Ground Truth"""
    
    idx = row.name
    
    # Load data
    volume, modality, label_dir = load_original_volume(series_uid, row['Modality'], base_dirs)
    if volume is None:
        print(f"Warning: Could not load volume for {series_uid}")
        return
    
    # Get center slice (where aneurysm is most likely visible)
    center_idx = 3
    original_slice = volume[:, :, center_idx]
    
    # Get predicted mask
    pred_mask = predictions_data['segmentation_preds'][idx, 0]  # (256, 256)
    
    # Get ground truth mask
    gt_mask = load_ground_truth_mask(series_uid, modality, config)
    
    # Create figure
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Ground truth label
    gt_label = "Aneurysm" if label_dir == 'aneurysm' else "No Aneurysm"
    pred_label = "Aneurysm" if row['Predicted_Aneurysm'] == 1 else "No Aneurysm"
    confidence = row['Aneurysm_Probability']
    
    fig.suptitle(
        f"Series: {series_uid[:40]}...\n"
        f"Modality: {modality} | GT: {gt_label} | Pred: {pred_label} ({confidence:.1%})",
        fontsize=12, fontweight='bold'
    )
    
    # Panel 1: Original slice
    axes[0].imshow(original_slice, cmap='gray')
    axes[0].set_title('Original Image (Center Slice)', fontsize=11, fontweight='bold')
    axes[0].axis('off')
    
    # Panel 2: Predicted mask overlay
    axes[1].imshow(original_slice, cmap='gray')
    pred_masked = np.ma.masked_where(pred_mask < 0.3, pred_mask)
    axes[1].imshow(pred_masked, cmap='hot', alpha=0.6, vmin=0, vmax=1)
    axes[1].set_title(f'Predicted Segmentation\n(Max: {pred_mask.max():.3f})', 
                     fontsize=11, fontweight='bold')
    axes[1].axis('off')
    
    # Panel 3: Ground truth mask overlay
    axes[2].imshow(original_slice, cmap='gray')
    if gt_mask is not None and gt_mask.sum() > 0:
        # Only show pixels where mask is 1
        gt_masked = np.ma.masked_where(gt_mask < 0.99, gt_mask)
        axes[2].imshow(gt_masked, cmap='Greens', alpha=0.7, vmin=0, vmax=1)
        axes[2].set_title(f'Ground Truth Segmentation\n(Pixels: {int(gt_mask.sum())})', 
                         fontsize=11, fontweight='bold')
    else:
        axes[2].text(0.5, 0.5, 'GT Mask\nNot Available', 
                    ha='center', va='center', fontsize=14, 
                    transform=axes[2].transAxes, color='red', fontweight='bold')
        axes[2].set_title('Ground Truth Segmentation', fontsize=11, fontweight='bold')
    axes[2].axis('off')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Saved: {save_path}")
        plt.close()
    else:
        plt.show()
        plt.close()


def main():
    parser = argparse.ArgumentParser(description='Simple Visualization: Original vs Predicted vs GT')
    parser.add_argument('--predictions_dir', type=str, required=True,
                       help='Directory containing predictions')
    parser.add_argument('--series_uid', type=str, default=None,
                       help='Visualize specific series UID')
    parser.add_argument('--top_n', type=int, default=10,
                       help='Number of top positive predictions to visualize (default: 10)')
    parser.add_argument('--save_all', action='store_true',
                       help='Save all visualizations')
    
    args = parser.parse_args()
    
    # Validate directory
    if not os.path.exists(args.predictions_dir):
        print(f"ERROR: Directory not found: {args.predictions_dir}")
        return
    
    # Load predictions
    csv_path = os.path.join(args.predictions_dir, 'predictions.csv')
    npz_path = os.path.join(args.predictions_dir, 'predictions.npz')
    
    if not os.path.exists(csv_path) or not os.path.exists(npz_path):
        print(f"ERROR: Prediction files not found")
        return
    
    print("Loading predictions...")
    df = pd.read_csv(csv_path)
    predictions_data = np.load(npz_path)
    print(f"Loaded {len(df)} predictions")
    
    # Setup config
    config = Config()
    base_dirs = {
        'CTA': config.data.preprocessed_cta_dir,
        'MRA': config.data.preprocessed_mra_dir,
        'MRI': config.data.preprocessed_mri_dir
    }
    
    # Create output directory
    viz_dir = os.path.join(args.predictions_dir, 'simple_viz')
    os.makedirs(viz_dir, exist_ok=True)
    
    # Visualize specific series
    if args.series_uid:
        series_row = df[df['SeriesInstanceUID'] == args.series_uid]
        if len(series_row) == 0:
            print(f"ERROR: Series UID not found: {args.series_uid}")
            return
        
        save_path = os.path.join(viz_dir, f"{args.series_uid}.png")
        visualize_comparison(args.series_uid, series_row.iloc[0], 
                           predictions_data, base_dirs, config, save_path)
    
    # Visualize all
    elif args.save_all:
        print(f"\nGenerating {len(df)} visualizations...")
        for idx, row in tqdm(df.iterrows(), total=len(df)):
            series_uid = row['SeriesInstanceUID']
            save_path = os.path.join(viz_dir, f"{idx:04d}_{series_uid[:20]}.png")
            visualize_comparison(series_uid, row, predictions_data, base_dirs, config, save_path)
    
    # Visualize top N positive predictions
    else:
        # Filter for aneurysm predictions
        aneurysm_cases = df[df['Predicted_Aneurysm'] == 1].copy()
        if len(aneurysm_cases) == 0:
            print("No positive aneurysm predictions found!")
            return
        
        # Sort by confidence
        aneurysm_cases = aneurysm_cases.sort_values('Aneurysm_Probability', ascending=False)
        
        print(f"\nVisualizing top {args.top_n} positive predictions...")
        print(f"Total positive predictions: {len(aneurysm_cases)}")
        
        for i, (idx, row) in enumerate(aneurysm_cases.head(args.top_n).iterrows()):
            series_uid = row['SeriesInstanceUID']
            confidence = row['Aneurysm_Probability']
            save_path = os.path.join(viz_dir, f"top_{i+1:02d}_conf{confidence:.3f}_{series_uid[:15]}.png")
            
            print(f"[{i+1}/{args.top_n}] {series_uid[:40]}... (confidence: {confidence:.3f})")
            visualize_comparison(series_uid, row, predictions_data, base_dirs, config, save_path)
    
    print("\n" + "=" * 80)
    print(f"[OK] Visualizations saved to: {viz_dir}")
    print("=" * 80)


if __name__ == "__main__":
    main()
