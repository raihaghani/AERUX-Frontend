"""
Quick Visualization Runner

Automatically finds latest inference results and creates visualizations.
"""

import os
import glob
from datetime import datetime

print("=" * 80)
print("SEARCHING FOR INFERENCE RESULTS")
print("=" * 80)

# Find latest fusion output directory with predictions
pattern = "E:/Education/Aerux_Final/outputs/fusion_*/predictions.csv"
prediction_files = glob.glob(pattern)

if not prediction_files:
    print("\nERROR: No prediction files found!")
    print(f"Pattern searched: {pattern}")
    print("\nPlease run inference first:")
    print("  python run_inference.py")
    exit(1)

# Sort by modification time, most recent first
prediction_files.sort(key=os.path.getmtime, reverse=True)
latest_predictions = prediction_files[0]
predictions_dir = os.path.dirname(latest_predictions)

mod_time = os.path.getmtime(latest_predictions)
mod_date = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')

print(f"\n[OK] Found predictions: {predictions_dir}")
print(f"     Generated: {mod_date}")

# Build command
command = f'python visualize_predictions.py --predictions_dir "{predictions_dir}" --top_n 10 --show_uncertain'

print("\n" + "=" * 80)
print("CREATING VISUALIZATIONS")
print("=" * 80)
print(f"\nCommand: {command}\n")
print("=" * 80)

# Execute
os.system(command)
