"""
Visualization Script for Fusion Model Predictions

Visualizes:
1. Original image slices
2. Predicted segmentation masks
3. Aneurysm detection confidence
4. Location predictions

Usage:
    # Visualize predictions from inference
    python visualize_predictions.py --predictions_dir outputs/fusion_20251209_142629
    
    # Visualize specific series
    python visualize_predictions.py --predictions_dir outputs/fusion_20251209_142629 --series_uid 1.2.826...
    
    # Save all visualizations
    python visualize_predictions.py --predictions_dir outputs/fusion_20251209_142629 --save_all
"""

import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).parent))
from config.config import Config
from train_multitask import LOCATION_LABELS

# Set style
sns.set_style('whitegrid')
plt.rcParams['figure.figsize'] = (20, 12)


def load_original_volume(series_uid, modality, base_dirs):
    """Load the original preprocessed volume"""
    # Try both aneurysm and no_aneurysm folders
    for label_dir in ['aneurysm', 'no_aneurysm']:
        for mod_name in ['CTA', 'MRA', 'MRI']:
            if modality.upper().startswith(mod_name):
                base_dir = base_dirs[mod_name]
                file_path = os.path.join(base_dir, label_dir, f"{series_uid}.npy")
                if os.path.exists(file_path):
                    volume = np.load(file_path)  # Shape: (256, 256, 7)
                    return volume, mod_name
    return None, None


def visualize_single_prediction(series_uid, row, predictions_data, base_dirs, save_path=None):
    """Visualize prediction for a single series"""
    
    # Get prediction index
    idx = row.name
    
    # Load original volume
    volume, detected_modality = load_original_volume(series_uid, row['Modality'], base_dirs)
    
    if volume is None:
        print(f"Warning: Could not load volume for {series_uid}")
        return
    
    # Get predictions
    det_prob = row['Aneurysm_Probability']
    det_pred = row['Predicted_Aneurysm']
    
    # Get segmentation mask
    seg_mask = predictions_data['segmentation_preds'][idx, 0]  # (256, 256)
    
    # Get location predictions
    location_probs = {}
    for i, loc in enumerate(LOCATION_LABELS):
        if f'{loc}_Prob' in row:
            location_probs[loc] = row[f'{loc}_Prob']
    
    # Create figure
    fig = plt.figure(figsize=(20, 12))
    gs = fig.add_gridspec(3, 5, hspace=0.3, wspace=0.3)
    
    # Title
    gt_label = "Aneurysm" if row.get('Aneurysm Present', -1) == 1 else "No Aneurysm" if row.get('Aneurysm Present', -1) == 0 else "Unknown"
    pred_label = "Aneurysm" if det_pred == 1 else "No Aneurysm"
    
    fig.suptitle(
        f"Series: {series_uid[:30]}...\n"
        f"Modality: {row['Modality']} | Ground Truth: {gt_label} | "
        f"Predicted: {pred_label} (confidence: {det_prob:.1%})",
        fontsize=14, fontweight='bold'
    )
    
    # Row 1: Original slices (7 channels)
    for i in range(7):
        ax = fig.add_subplot(gs[0, i if i < 5 else i-5])
        slice_img = volume[:, :, i]
        ax.imshow(slice_img, cmap='gray')
        ax.set_title(f'Slice {i+1}', fontsize=10)
        ax.axis('off')
    
    # Row 2: Segmentation overlays on center slices
    center_idx = 3  # Middle slice
    
    # Original center slice
    ax1 = fig.add_subplot(gs[1, 0])
    ax1.imshow(volume[:, :, center_idx], cmap='gray')
    ax1.set_title('Center Slice', fontsize=10)
    ax1.axis('off')
    
    # Segmentation mask
    ax2 = fig.add_subplot(gs[1, 1])
    ax2.imshow(seg_mask, cmap='hot', vmin=0, vmax=1)
    ax2.set_title('Predicted Mask', fontsize=10)
    ax2.axis('off')
    cbar = plt.colorbar(ax2.images[0], ax=ax2, fraction=0.046)
    cbar.set_label('Probability', fontsize=8)
    
    # Overlay
    ax3 = fig.add_subplot(gs[1, 2])
    ax3.imshow(volume[:, :, center_idx], cmap='gray')
    masked = np.ma.masked_where(seg_mask < 0.3, seg_mask)
    ax3.imshow(masked, cmap='hot', alpha=0.6, vmin=0, vmax=1)
    ax3.set_title('Overlay (threshold=0.3)', fontsize=10)
    ax3.axis('off')
    
    # Thresholded mask
    ax4 = fig.add_subplot(gs[1, 3])
    ax4.imshow(volume[:, :, center_idx], cmap='gray')
    binary_mask = (seg_mask > 0.5).astype(float)
    masked_binary = np.ma.masked_where(binary_mask < 0.5, binary_mask)
    ax4.imshow(masked_binary, cmap='Reds', alpha=0.7)
    ax4.set_title('Binary Mask (threshold=0.5)', fontsize=10)
    ax4.axis('off')
    
    # Detection confidence
    ax5 = fig.add_subplot(gs[1, 4])
    colors = ['green' if det_pred == 0 else 'red']
    ax5.barh(['Prediction'], [det_prob], color=colors, alpha=0.7)
    ax5.set_xlim(0, 1)
    ax5.set_xlabel('Confidence', fontsize=10)
    ax5.set_title('Detection Confidence', fontsize=10)
    ax5.axvline(0.5, color='black', linestyle='--', linewidth=1)
    for spine in ax5.spines.values():
        spine.set_visible(False)
    
    # Row 3: Location predictions
    ax6 = fig.add_subplot(gs[2, :])
    
    if location_probs:
        # Sort by probability
        sorted_locs = sorted(location_probs.items(), key=lambda x: x[1], reverse=True)
        locations = [loc.replace('Internal Carotid Artery', 'ICA').replace('Artery', 'A.') for loc, _ in sorted_locs]
        probs = [prob for _, prob in sorted_locs]
        
        # Color based on probability
        colors = ['red' if p > 0.5 else 'orange' if p > 0.3 else 'yellow' if p > 0.1 else 'lightgray' 
                  for p in probs]
        
        bars = ax6.barh(locations, probs, color=colors, alpha=0.7)
        ax6.set_xlabel('Probability', fontsize=10)
        ax6.set_title('Anatomical Location Predictions', fontsize=12, fontweight='bold')
        ax6.set_xlim(0, 1)
        ax6.axvline(0.5, color='red', linestyle='--', linewidth=1, label='High confidence')
        ax6.axvline(0.3, color='orange', linestyle='--', linewidth=1, label='Moderate')
        ax6.legend(fontsize=8, loc='lower right')
        
        # Add probability labels on bars
        for i, (bar, prob) in enumerate(zip(bars, probs)):
            if prob > 0.05:
                ax6.text(prob + 0.02, i, f'{prob:.2f}', va='center', fontsize=8)
    else:
        ax6.text(0.5, 0.5, 'Location data not available', 
                ha='center', va='center', fontsize=12, transform=ax6.transAxes)
        ax6.set_xlim(0, 1)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Saved: {save_path}")
    else:
        plt.show()
    
    plt.close()


def create_summary_visualization(df, predictions_data, output_dir):
    """Create summary visualizations for all predictions"""
    
    print("\nCreating summary visualizations...")
    
    # Figure 1: Detection Results Overview
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    fig.suptitle('Detection Results Summary', fontsize=16, fontweight='bold')
    
    # 1. Probability distribution
    axes[0, 0].hist(df['Aneurysm_Probability'], bins=50, alpha=0.7, color='steelblue', edgecolor='black')
    axes[0, 0].axvline(0.5, color='red', linestyle='--', linewidth=2, label='Threshold')
    axes[0, 0].set_xlabel('Aneurysm Probability', fontsize=11)
    axes[0, 0].set_ylabel('Count', fontsize=11)
    axes[0, 0].set_title('Probability Distribution', fontsize=12)
    axes[0, 0].legend()
    axes[0, 0].grid(alpha=0.3)
    
    # 2. Predictions by modality
    if 'Modality' in df.columns:
        modality_counts = df.groupby(['Modality', 'Predicted_Aneurysm']).size().unstack(fill_value=0)
        modality_counts.plot(kind='bar', stacked=True, ax=axes[0, 1], 
                            color=['lightgreen', 'salmon'], alpha=0.8)
        axes[0, 1].set_xlabel('Modality', fontsize=11)
        axes[0, 1].set_ylabel('Count', fontsize=11)
        axes[0, 1].set_title('Predictions by Modality', fontsize=12)
        axes[0, 1].legend(['No Aneurysm', 'Aneurysm'], fontsize=9)
        axes[0, 1].tick_params(axis='x', rotation=45)
        axes[0, 1].grid(alpha=0.3)
    
    # 3. Confusion matrix (if ground truth available)
    if 'Aneurysm Present' in df.columns:
        from sklearn.metrics import confusion_matrix
        cm = confusion_matrix(df['Aneurysm Present'], df['Predicted_Aneurysm'])
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0, 2],
                   xticklabels=['No Aneurysm', 'Aneurysm'],
                   yticklabels=['No Aneurysm', 'Aneurysm'])
        axes[0, 2].set_xlabel('Predicted', fontsize=11)
        axes[0, 2].set_ylabel('Ground Truth', fontsize=11)
        axes[0, 2].set_title('Confusion Matrix', fontsize=12)
    
    # 4. High confidence predictions
    high_conf_positive = len(df[df['Aneurysm_Probability'] > 0.8])
    high_conf_negative = len(df[df['Aneurysm_Probability'] < 0.2])
    uncertain = len(df[(df['Aneurysm_Probability'] >= 0.4) & (df['Aneurysm_Probability'] <= 0.6)])
    
    categories = ['High Conf.\nAneurysm\n(>0.8)', 'Uncertain\n(0.4-0.6)', 'High Conf.\nNo Aneurysm\n(<0.2)']
    counts = [high_conf_positive, uncertain, high_conf_negative]
    colors_bar = ['red', 'yellow', 'green']
    
    axes[1, 0].bar(categories, counts, color=colors_bar, alpha=0.7, edgecolor='black')
    axes[1, 0].set_ylabel('Count', fontsize=11)
    axes[1, 0].set_title('Confidence Distribution', fontsize=12)
    axes[1, 0].grid(alpha=0.3, axis='y')
    
    # Add count labels on bars
    for i, (cat, count) in enumerate(zip(categories, counts)):
        axes[1, 0].text(i, count + max(counts)*0.02, str(count), 
                       ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    # 5. Average segmentation mask
    avg_mask = predictions_data['segmentation_preds'].mean(axis=0)[0]
    im = axes[1, 1].imshow(avg_mask, cmap='hot', vmin=0, vmax=1)
    axes[1, 1].set_title('Average Segmentation Mask', fontsize=12)
    axes[1, 1].axis('off')
    plt.colorbar(im, ax=axes[1, 1], fraction=0.046)
    
    # 6. ROC curve (if ground truth available)
    if 'Aneurysm Present' in df.columns:
        from sklearn.metrics import roc_curve, auc
        fpr, tpr, _ = roc_curve(df['Aneurysm Present'], df['Aneurysm_Probability'])
        roc_auc = auc(fpr, tpr)
        
        axes[1, 2].plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC (AUC = {roc_auc:.3f})')
        axes[1, 2].plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random')
        axes[1, 2].set_xlabel('False Positive Rate', fontsize=11)
        axes[1, 2].set_ylabel('True Positive Rate', fontsize=11)
        axes[1, 2].set_title('ROC Curve', fontsize=12)
        axes[1, 2].legend(fontsize=10)
        axes[1, 2].grid(alpha=0.3)
    
    plt.tight_layout()
    summary_path = os.path.join(output_dir, 'detection_summary.png')
    plt.savefig(summary_path, dpi=300, bbox_inches='tight')
    print(f"Saved: {summary_path}")
    plt.close()
    
    # Figure 2: Location Analysis
    location_cols = [col for col in df.columns if '_Prob' in col and col != 'Aneurysm_Probability']
    if location_cols:
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        fig.suptitle('Anatomical Location Analysis', fontsize=16, fontweight='bold')
        
        # Average location probabilities
        location_means = df[location_cols].mean()
        location_names = [col.replace('_Prob', '').replace('Internal Carotid Artery', 'ICA').replace('Artery', 'A.') 
                         for col in location_cols]
        
        # Sort by probability
        sorted_indices = location_means.argsort()
        
        axes[0].barh(range(len(location_names)), location_means[sorted_indices], 
                    color='steelblue', alpha=0.7, edgecolor='black')
        axes[0].set_yticks(range(len(location_names)))
        axes[0].set_yticklabels([location_names[i] for i in sorted_indices], fontsize=9)
        axes[0].set_xlabel('Average Probability', fontsize=11)
        axes[0].set_title('Average Location Predictions', fontsize=12)
        axes[0].grid(alpha=0.3, axis='x')
        
        # Location heatmap for positive predictions
        positive_cases = df[df['Predicted_Aneurysm'] == 1]
        if len(positive_cases) > 0:
            location_matrix = positive_cases[location_cols].values.T
            im = axes[1].imshow(location_matrix, aspect='auto', cmap='YlOrRd', vmin=0, vmax=1)
            axes[1].set_yticks(range(len(location_names)))
            axes[1].set_yticklabels(location_names, fontsize=9)
            axes[1].set_xlabel('Sample Index (Positive Cases)', fontsize=11)
            axes[1].set_title(f'Location Heatmap ({len(positive_cases)} Positive Cases)', fontsize=12)
            plt.colorbar(im, ax=axes[1], label='Probability')
        
        plt.tight_layout()
        location_path = os.path.join(output_dir, 'location_analysis.png')
        plt.savefig(location_path, dpi=300, bbox_inches='tight')
        print(f"Saved: {location_path}")
        plt.close()


def main():
    parser = argparse.ArgumentParser(description='Visualize Fusion Model Predictions')
    parser.add_argument('--predictions_dir', type=str, required=True,
                       help='Directory containing predictions (e.g., outputs/fusion_YYYYMMDD_HHMMSS)')
    parser.add_argument('--series_uid', type=str, default=None,
                       help='Visualize specific series UID (if not provided, shows top predictions)')
    parser.add_argument('--save_all', action='store_true',
                       help='Save visualizations for all samples')
    parser.add_argument('--top_n', type=int, default=10,
                       help='Number of top predictions to visualize (default: 10)')
    parser.add_argument('--show_uncertain', action='store_true',
                       help='Also show uncertain predictions (0.4-0.6)')
    
    args = parser.parse_args()
    
    # Validate predictions directory
    if not os.path.exists(args.predictions_dir):
        print(f"ERROR: Predictions directory not found: {args.predictions_dir}")
        return
    
    # Load predictions
    csv_path = os.path.join(args.predictions_dir, 'predictions.csv')
    npz_path = os.path.join(args.predictions_dir, 'predictions.npz')
    
    if not os.path.exists(csv_path) or not os.path.exists(npz_path):
        print(f"ERROR: Prediction files not found in {args.predictions_dir}")
        print("Expected: predictions.csv and predictions.npz")
        return
    
    print("Loading predictions...")
    df = pd.read_csv(csv_path)
    predictions_data = np.load(npz_path)
    
    print(f"Loaded {len(df)} predictions")
    
    # Setup config
    config = Config()
    base_dirs = {
        'CTA': config.data.preprocessed_cta_dir,
        'MRA': config.data.preprocessed_mra_dir,
        'MRI': config.data.preprocessed_mri_dir
    }
    
    # Create visualization directory
    viz_dir = os.path.join(args.predictions_dir, 'visualizations')
    os.makedirs(viz_dir, exist_ok=True)
    
    # Create summary visualizations
    create_summary_visualization(df, predictions_data, viz_dir)
    
    # Visualize specific series
    if args.series_uid:
        series_row = df[df['SeriesInstanceUID'] == args.series_uid]
        if len(series_row) == 0:
            print(f"ERROR: Series UID not found: {args.series_uid}")
            return
        
        save_path = os.path.join(viz_dir, f"{args.series_uid}.png")
        visualize_single_prediction(args.series_uid, series_row.iloc[0], 
                                   predictions_data, base_dirs, save_path)
    
    # Visualize all samples
    elif args.save_all:
        print(f"\nGenerating visualizations for all {len(df)} samples...")
        sample_dir = os.path.join(viz_dir, 'samples')
        os.makedirs(sample_dir, exist_ok=True)
        
        for idx, row in tqdm(df.iterrows(), total=len(df)):
            series_uid = row['SeriesInstanceUID']
            save_path = os.path.join(sample_dir, f"{idx:04d}_{series_uid[:20]}.png")
            visualize_single_prediction(series_uid, row, predictions_data, base_dirs, save_path)
    
    # Visualize top predictions
    else:
        print(f"\nGenerating visualizations for top {args.top_n} predictions...")
        
        # Sort by probability (highest aneurysm confidence)
        df_sorted = df.sort_values('Aneurysm_Probability', ascending=False)
        
        # Top positive predictions
        print(f"\n1. Top {args.top_n} HIGH CONFIDENCE aneurysm predictions:")
        for i, (idx, row) in enumerate(df_sorted.head(args.top_n).iterrows()):
            series_uid = row['SeriesInstanceUID']
            save_path = os.path.join(viz_dir, f"top_positive_{i+1:02d}_{series_uid[:20]}.png")
            print(f"   [{i+1}/{args.top_n}] {series_uid[:30]}... (prob: {row['Aneurysm_Probability']:.3f})")
            visualize_single_prediction(series_uid, row, predictions_data, base_dirs, save_path)
        
        # If uncertain predictions requested
        if args.show_uncertain:
            uncertain = df[(df['Aneurysm_Probability'] >= 0.4) & (df['Aneurysm_Probability'] <= 0.6)]
            if len(uncertain) > 0:
                print(f"\n2. UNCERTAIN predictions (0.4-0.6):")
                for i, (idx, row) in enumerate(uncertain.head(5).iterrows()):
                    series_uid = row['SeriesInstanceUID']
                    save_path = os.path.join(viz_dir, f"uncertain_{i+1:02d}_{series_uid[:20]}.png")
                    print(f"   [{i+1}] {series_uid[:30]}... (prob: {row['Aneurysm_Probability']:.3f})")
                    visualize_single_prediction(series_uid, row, predictions_data, base_dirs, save_path)
    
    print("\n" + "=" * 80)
    print(f"[OK] All visualizations saved to: {viz_dir}")
    print("=" * 80)


if __name__ == "__main__":
    main()
