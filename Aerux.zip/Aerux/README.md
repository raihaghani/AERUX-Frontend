# Intracranial Aneurysm Detection, Localization, and Segmentation

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

A professional, modular deep learning pipeline for multi-task intracranial aneurysm analysis using multi-modal medical imaging (CTA, MRA, MRI). The system performs:

1. **Binary Detection**: Aneurysm present or not
2. **Location Classification**: 12 specific anatomical locations
3. **Segmentation**: Pixel-level aneurysm delineation

## 🌟 Key Features

- **Multi-Modal Fusion**: Integrates CTA, MRA, MRI T1post, and MRI T2 imaging using attention mechanisms
- **Multi-Task Learning**: Simultaneous detection, localization, and segmentation
- **Attention Mechanisms**: Multi-head attention and spatial attention for interpretability
- **2.5D Architecture**: ResNet50-based backbone adapted for medical imaging
- **Professional Codebase**: Modular, well-documented, and production-ready
- **Comprehensive Evaluation**: AUC, Dice, IoU, confusion matrices, and visualization

---

## 📁 Project Structure

```
Aerux_Final/
├── config/
│   └── config.py              # Configuration management (12 location labels, hyperparameters)
├── data/
│   ├── dataset.py             # Multi-modal dataset loader with augmentation support
│   └── preprocessing.py       # Medical image preprocessing (N4, HU windowing, vesselness)
├── models/
│   ├── resnet_2_5d.py        # ResNet 2.5D backbone with multi-task heads
│   └── fusion.py              # Attention-based multi-modal fusion network
├── training/
│   ├── losses.py              # Multi-task loss functions (Focal, Dice, BCE)
│   └── trainer.py             # Training loop with metrics tracking & checkpointing
├── inference/
│   └── inference.py           # Inference engine and evaluation metrics
├── utils/
│   └── visualization.py       # Visualization tools (ROC, attention maps, segmentation)
├── train.py                   # Main training script
├── inference.py               # Main inference script
├── README.md                  # This file
└── requirements.txt           # Python dependencies
```

---

## 🚀 Quick Start

### 1. Installation

```bash
# Clone the repository
cd E:\Education\Aerux_Final

# Install dependencies
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install numpy pandas scikit-learn matplotlib seaborn tqdm pyyaml opencv-python
```

### 2. Dataset Organization

Ensure your dataset follows this structure:

```
D:\FYP_Data\rsna-intracranial-aneurysm-detection\
├── train.csv                  # Contains 12 location labels + metadata
├── train_localizers.csv       # Bounding box coordinates
├── series/                    # DICOM files
└── segmentations/             # Segmentation masks (if available)

E:\Education\FYP\Preprocessed_images_2.5D\
├── CTA/
│   ├── aneurysm/              # Positive cases
│   └── no_aneurysm/           # Negative cases
├── MRA/
│   ├── aneurysm/
│   └── no_aneurysm/
└── MRI/
    ├── aneurysm/
    └── no_aneurysm/
```

### 3. Preprocessing Techniques (Optional)

The pipeline includes advanced preprocessing techniques from the original research:

#### MRI/MRA Preprocessing Pipeline
1. **N4 Bias Field Correction** - Removes intensity non-uniformity caused by magnetic field inhomogeneities
2. **Sato Vesselness Filter** - Enhances tubular structures (blood vessels) using Hessian-based filtering
3. **Otsu Thresholding** (optional) - Automatic binary segmentation

#### CTA Preprocessing Pipeline
1. **HU (Hounsfield Unit) Windowing** - Focuses on specific tissue density range (default: 40±40 HU for brain/vessels)
2. **CLAHE** (optional) - Contrast Limited Adaptive Histogram Equalization for local contrast enhancement
3. **Sato Vesselness Filter** - Vessel enhancement after HU windowing

#### Enabling Preprocessing

**Via Configuration File (config.yaml):**
```yaml
data:
  # Enable preprocessing
  apply_preprocessing: true
  
  # MRI/MRA settings
  mri_apply_n4: true
  mri_apply_vesselness: true
  mri_apply_otsu: false
  mri_vesselness_scale_range: [1, 8]
  
  # CTA settings
  cta_apply_hu_windowing: true
  cta_window_center: 40.0
  cta_window_width: 80.0
  cta_apply_clahe: false  # Can cause artifacts
  cta_apply_vesselness: true
```

**Via Python Code:**
```python
from data.preprocessing import create_preprocessor

# Create MRI preprocessor
mri_prep = create_preprocessor('MRI', 
                               apply_n4=True,
                               apply_vesselness=True,
                               apply_otsu=False)

# Apply preprocessing
result = mri_prep.preprocess(image)
preprocessed_image = result['preprocessed']

# Create CTA preprocessor
cta_prep = create_preprocessor('CTA',
                               apply_hu_windowing=True,
                               window_center=40,
                               window_width=80,
                               apply_vesselness=True)

result = cta_prep.preprocess(image)
preprocessed_image = result['preprocessed']
```

**Note:** Install required packages for preprocessing:
```bash
pip install SimpleITK scikit-image
```

These preprocessing techniques are applied **on-the-fly during data loading** if enabled in the configuration. They are **optional** and the pipeline works with pre-processed images as well.

### 5. Training

#### Single-Modal Training (CTA only)
```bash
python train.py --mode single_modal --modality CTA --num_epochs 50 --batch_size 8
```

#### Multi-Modal Training with Fusion
```bash
python train.py --mode multi_modal --freeze_encoders --num_epochs 100 --batch_size 4
```

#### Resume Training
```bash
python train.py --resume outputs/checkpoints/latest_checkpoint.pth
```

### 6. Inference & Evaluation

```bash
# Run inference on test set
python inference.py \
    --checkpoint outputs/checkpoints/best_model.pth \
    --mode single_modal \
    --data_split test \
    --save_predictions \
    --visualize
```

---

## 📊 12 Aneurysm Location Labels

The model classifies aneurysms into these specific anatomical locations:

1. Left Infraclinoid Internal Carotid Artery
2. Right Infraclinoid Internal Carotid Artery
3. Left Supraclinoid Internal Carotid Artery
4. Right Supraclinoid Internal Carotid Artery
5. Left Middle Cerebral Artery
6. Right Middle Cerebral Artery
7. Anterior Communicating Artery
8. Left Anterior Cerebral Artery
9. Right Anterior Cerebral Artery
10. Left Posterior Communicating Artery
11. Right Posterior Communicating Artery
12. Basilar Tip
13. Other Posterior Circulation

---

## ⚙️ Configuration

The `config/config.py` file contains all hyperparameters. Key sections:

### Data Configuration
- Dataset paths (CSV files, preprocessed images)
- Train/val/test split ratios
- Image preprocessing parameters (size, normalization)
- 12 location labels

### Model Configuration
- Backbone architecture (ResNet50)
- Multi-task head dimensions
- Attention mechanism settings
- Dropout rates

### Training Configuration
- Optimizer (Adam/AdamW/SGD)
- Learning rate & scheduler
- Loss weights (detection: 1.0, localization: 1.0, segmentation: 2.0)
- Batch size, epochs, early stopping
- Mixed precision training (AMP)

### Example YAML Configuration

```yaml
data:
  train_csv: "D:/FYP_Data/rsna-intracranial-aneurysm-detection/train.csv"
  preprocessed_cta_dir: "E:/Education/FYP/Preprocessed_images_2.5D/CTA"
  target_size: [256, 256]
  num_slices: 7

model:
  backbone: "resnet50"
  num_detection_classes: 2
  num_location_classes: 13
  enable_segmentation: true

training:
  num_epochs: 100
  batch_size: 8
  learning_rate: 0.0001
  detection_loss_weight: 1.0
  localization_loss_weight: 1.0
  segmentation_loss_weight: 2.0
```

---

## 🧠 Model Architecture

### ResNet 2.5D Backbone
- Modified ResNet50 with 7-channel input (2.5D slices)
- Pretrained ImageNet weights adapted for medical imaging
- Multi-scale feature extraction (layer1-4)

### Multi-Task Heads

#### 1. Detection Head
- Global average pooling → FC layers
- Binary classification (aneurysm present/absent)
- Output: 2 classes

#### 2. Location Classification Head
- Spatial attention mechanism
- Multi-class classification
- Output: 13 classes (12 locations + no aneurysm)

#### 3. Segmentation Decoder
- U-Net style decoder with skip connections
- Upsampling to original resolution
- Output: Binary segmentation mask

### Attention-Based Fusion
- **Cross-Modal Attention**: Fuses features from different modalities
- **Spatial Attention**: Focuses on relevant image regions
- **Modality Weighting**: Learns adaptive weights for each modality

---

## 📈 Training Details

### Loss Functions
1. **Detection Loss**: Cross-Entropy or Focal Loss (for class imbalance)
2. **Localization Loss**: Cross-Entropy
3. **Segmentation Loss**: Dice Loss + Binary Cross-Entropy (50/50 mix)

**Combined Loss:**
```
L_total = w_det * L_det + w_loc * L_loc + w_seg * L_seg
```

### Data Augmentation
- Random rotation (±15°)
- Random horizontal flip (50%)
- Random scale (0.9-1.1)
- Random brightness/contrast adjustment
- Gaussian noise

### Optimization
- **Optimizer**: Adam (lr=1e-4, weight_decay=1e-4)
- **Scheduler**: Cosine Annealing
- **Mixed Precision**: Enabled (FP16)
- **Gradient Accumulation**: 4 steps
- **Early Stopping**: Patience=20 epochs

---

## 📊 Evaluation Metrics

### Detection Metrics
- **AUC-ROC**: Area under ROC curve
- **Accuracy**: Overall classification accuracy
- **Precision, Recall, F1-Score**: Per-class metrics
- **Confusion Matrix**: 2×2 matrix

### Location Metrics
- **Accuracy**: Multi-class classification accuracy
- **Per-Class Precision/Recall**: For each of 12 locations
- **Confusion Matrix**: 13×13 matrix

### Segmentation Metrics
- **Dice Coefficient**: Overlap measure (mean ± std)
- **IoU (Intersection over Union)**: Jaccard index
- **Pixel Accuracy**: Correct pixels / total pixels

---

## 🎨 Visualization Tools

The pipeline generates comprehensive visualizations:

1. **Training History**: Loss curves, accuracy plots
2. **ROC Curve**: Detection performance
3. **Confusion Matrices**: Detection and location classification
4. **Attention Maps**: Spatial attention heatmaps
5. **Segmentation Overlays**: Predicted vs ground truth masks
6. **Location Distribution**: Class distribution analysis

Example:
```python
from utils.visualization import create_visualization_report

create_visualization_report(
    metrics=eval_metrics,
    train_history=train_history,
    val_history=val_history,
    results=eval_results,
    location_labels=config.data.location_labels,
    output_dir='visualizations/'
)
```

---

## 🔬 Advanced Usage

### Custom Configuration

Create a custom `config.yaml`:

```yaml
data:
  train_ratio: 0.7
  val_ratio: 0.15
  test_ratio: 0.15

model:
  backbone: "resnet50"
  fusion_dim: 512
  num_attention_heads: 8

training:
  num_epochs: 150
  batch_size: 12
  learning_rate: 0.0001
  use_amp: true
```

Load with:
```bash
python train.py --config my_config.yaml
```

### Fine-Tuning Multi-Modal Models

1. Train single-modal models first:
```bash
python train.py --mode single_modal --modality CTA --num_epochs 50
python train.py --mode single_modal --modality MRA --num_epochs 50
```

2. Train fusion network with frozen encoders:
```bash
python train.py --mode multi_modal --freeze_encoders --num_epochs 100
```

3. Fine-tune end-to-end (optional):
```bash
python train.py --mode multi_modal --num_epochs 50
```

### Ensemble Inference

Combine predictions from multiple models for improved performance:

```python
# Load multiple checkpoints
checkpoints = [
    'outputs/cta_model/best_model.pth',
    'outputs/mra_model/best_model.pth',
    'outputs/fusion_model/best_model.pth'
]

# Average predictions (implement custom logic)
```

---

## 📚 API Reference

### Dataset API

```python
from data.dataset import AneurysmDataset, create_dataloaders

# Create dataset
dataset = AneurysmDataset(
    data_info=train_df,
    modality_dirs={'CTA': 'path/to/cta', 'MRA': 'path/to/mra'},
    location_labels=location_labels,
    target_size=(256, 256),
    num_slices=7
)

# Get sample
sample = dataset[0]
# Returns: {
#   'cta': Tensor(7, 256, 256),
#   'detection_label': int,
#   'location_label': int,
#   'segmentation_mask': Tensor(256, 256)
# }
```

### Model API

```python
from models.resnet_2_5d import MultiTaskResNet2_5D

# Create model
model = MultiTaskResNet2_5D(
    input_channels=7,
    num_detection_classes=2,
    num_location_classes=13,
    num_segmentation_classes=2,
    enable_segmentation=True
)

# Forward pass
outputs = model(input_tensor)
# Returns: {
#   'detection_logits': Tensor(B, 2),
#   'location_logits': Tensor(B, 13),
#   'segmentation_logits': Tensor(B, 2, H, W),
#   'location_attention': Tensor(B, 1, H, W)
# }
```

### Training API

```python
from training.trainer import Trainer

trainer = Trainer(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    criterion=criterion,
    optimizer=optimizer,
    config=config,
    device=device
)

trainer.train(num_epochs=100)
```

---

## 🐛 Troubleshooting

### Common Issues

**Out of Memory (OOM)**
```bash
# Reduce batch size
python train.py --batch_size 4

# Enable gradient accumulation
# Edit config.py: accumulation_steps = 8
```

**CUDA Out of Memory**
```bash
# Use mixed precision training (enabled by default)
# Or reduce image size in config.py: target_size = (128, 128)
```

**Low Validation Performance**
- Check class imbalance (use class weights)
- Increase data augmentation
- Reduce learning rate
- Train for more epochs

**Segmentation Metrics are Zero**
- Ensure segmentation masks are available
- Check mask preprocessing (binary values 0/1)
- Increase segmentation loss weight

---

## 📄 Citation

If you use this codebase, please cite:

```bibtex
@software{aneurysm_detection_2025,
  title={Multi-Task Intracranial Aneurysm Detection, Localization, and Segmentation},
  author={Senior Computer Vision Engineer},
  year={2025},
  url={https://github.com/yourrepo/aerux_final}
}
```

---

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Commit your changes with clear messages
4. Submit a pull request

---

## 📧 Contact

For questions or issues:
- **GitHub Issues**: [github.com/yourrepo/issues](https://github.com/yourrepo/issues)
- **Email**: your.email@example.com

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- RSNA Intracranial Aneurysm Detection Challenge
- PyTorch Team for the deep learning framework
- ResNet authors for the backbone architecture
- Medical imaging community for dataset contributions

---

## 🔄 Version History

- **v1.0.0** (2025-01-08): Initial release
  - Multi-modal fusion with attention mechanisms
  - Multi-task learning (detection, localization, segmentation)
  - 12 location classification
  - Comprehensive evaluation and visualization

---

**Built with ❤️ for medical AI research**
