"""
Single Modality Training Script for ResNet50
Trains separate ResNet50 models for CTA, MRA, and MRI modalities
Saves best models and generates training plots

Usage:
    python train_single_modality.py --modality CTA
    python train_single_modality.py --modality MRA
    python train_single_modality.py --modality MRI
    python train_single_modality.py --all  # Train all three modalities sequentially
"""

import os
import sys
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from tqdm import tqdm
from datetime import datetime
import json

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.amp import autocast
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score, confusion_matrix

# Set style
sns.set_style('whitegrid')
plt.rcParams['figure.figsize'] = (12, 8)

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from config.config import Config


class AneurysmDataset(Dataset):
    """Dataset for single modality aneurysm detection"""
    
    def __init__(self, dataframe, modality, base_dir, augment=False):
        """
        Args:
            dataframe: DataFrame with SeriesInstanceUID and Aneurysm Present columns
            modality: 'CTA', 'MRA', or 'MRI'
            base_dir: Base directory containing preprocessed .npy files
            augment: Apply data augmentation
        """
        self.df = dataframe
        self.modality = modality
        self.base_dir = base_dir
        self.augment = augment
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        series_uid = row['SeriesInstanceUID']
        label = int(row['Aneurysm Present'])
        
        # Construct file path
        label_name = 'aneurysm' if label == 1 else 'no_aneurysm'
        file_path = os.path.join(self.base_dir, label_name, f"{series_uid}.npy")
        
        # Load preprocessed volume
        try:
            volume = np.load(file_path).astype(np.float32)  # Shape: (256, 256, 7)
            
            # Transpose to (7, 256, 256) for PyTorch
            volume = np.transpose(volume, (2, 0, 1))
            
            # Apply augmentation if enabled
            if self.augment:
                volume = self._augment(volume)
            
            return torch.from_numpy(volume), torch.tensor(label, dtype=torch.long)
        
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            # Return zero volume if file not found
            return torch.zeros((7, 256, 256), dtype=torch.float32), torch.tensor(label, dtype=torch.long)
    
    def _augment(self, volume):
        """Simple data augmentation"""
        # Random horizontal flip
        if np.random.rand() > 0.5:
            volume = np.flip(volume, axis=2).copy()
        
        # Random vertical flip
        if np.random.rand() > 0.5:
            volume = np.flip(volume, axis=1).copy()
        
        # Random rotation (90, 180, 270 degrees)
        if np.random.rand() > 0.5:
            k = np.random.randint(1, 4)
            volume = np.rot90(volume, k, axes=(1, 2)).copy()
        
        return volume


class ResNet50_2_5D(nn.Module):
    """ResNet50 adapted for 2.5D input (7 channels)"""
    
    def __init__(self, num_classes=2, input_channels=7, pretrained=True):
        super(ResNet50_2_5D, self).__init__()
        
        # Load pretrained ResNet50
        from torchvision import models
        if pretrained:
            resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        else:
            resnet = models.resnet50(weights=None)
        
        # Modify first conv layer to accept 7 channels
        self.conv1 = nn.Conv2d(input_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
        
        # Initialize new conv1 weights
        if pretrained:
            # Average pretrained weights across input channels
            pretrained_weights = resnet.conv1.weight.data
            self.conv1.weight.data = pretrained_weights.repeat(1, input_channels // 3 + 1, 1, 1)[:, :input_channels, :, :]
        
        # Copy remaining layers
        self.bn1 = resnet.bn1
        self.relu = resnet.relu
        self.maxpool = resnet.maxpool
        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        self.avgpool = resnet.avgpool
        
        # Classification head
        self.fc = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(2048, 512),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(512, num_classes)
        )
    
    def forward(self, x):
        # Encoder
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        # Global average pooling
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        
        # Classification
        x = self.fc(x)
        
        return x


def train_epoch(model, dataloader, criterion, optimizer, device, scaler=None):
    """Train for one epoch"""
    model.train()
    running_loss = 0.0
    all_preds = []
    all_labels = []
    all_probs = []
    
    progress_bar = tqdm(dataloader, desc='Training')
    
    for batch_idx, (inputs, labels) in enumerate(progress_bar):
        inputs, labels = inputs.to(device), labels.to(device)
        
        optimizer.zero_grad()
        
        # Mixed precision training
        if scaler is not None:
            with autocast('cuda'):
                outputs = model(inputs)
                loss = criterion(outputs, labels)
            
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
        
        # Statistics
        running_loss += loss.item()
        probs = torch.softmax(outputs, dim=1)[:, 1].detach().cpu().numpy()
        preds = torch.argmax(outputs, dim=1).detach().cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().numpy())
        all_probs.extend(probs)
        
        # Update progress bar
        progress_bar.set_postfix({'loss': loss.item()})
    
    epoch_loss = running_loss / len(dataloader)
    accuracy = accuracy_score(all_labels, all_preds)
    auc = roc_auc_score(all_labels, all_probs)
    
    return epoch_loss, accuracy, auc


def validate(model, dataloader, criterion, device):
    """Validate model"""
    model.eval()
    running_loss = 0.0
    all_preds = []
    all_labels = []
    all_probs = []
    
    with torch.no_grad():
        for inputs, labels in tqdm(dataloader, desc='Validating'):
            inputs, labels = inputs.to(device), labels.to(device)
            
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item()
            probs = torch.softmax(outputs, dim=1)[:, 1].cpu().numpy()
            preds = torch.argmax(outputs, dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(probs)
    
    epoch_loss = running_loss / len(dataloader)
    accuracy = accuracy_score(all_labels, all_preds)
    
    # Additional metrics
    precision, recall, f1, _ = precision_recall_fscore_support(all_labels, all_preds, average='binary', zero_division=0)
    auc = roc_auc_score(all_labels, all_probs)
    cm = confusion_matrix(all_labels, all_preds)
    
    metrics = {
        'loss': epoch_loss,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1,
        'auc': auc,
        'confusion_matrix': cm
    }
    
    return metrics


def plot_training_history(history, save_path):
    """Plot training history"""
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    
    # Loss
    axes[0, 0].plot(history['train_loss'], label='Train Loss', marker='o')
    axes[0, 0].plot(history['val_loss'], label='Val Loss', marker='o')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Loss')
    axes[0, 0].set_title('Training and Validation Loss')
    axes[0, 0].legend()
    axes[0, 0].grid(True)
    
    # Accuracy
    axes[0, 1].plot(history['train_acc'], label='Train Accuracy', marker='o')
    axes[0, 1].plot(history['val_acc'], label='Val Accuracy', marker='o')
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Accuracy')
    axes[0, 1].set_title('Training and Validation Accuracy')
    axes[0, 1].legend()
    axes[0, 1].grid(True)
    
    # AUC
    axes[1, 0].plot(history['train_auc'], label='Train AUC', marker='o')
    axes[1, 0].plot(history['val_auc'], label='Val AUC', marker='o')
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('AUC')
    axes[1, 0].set_title('Training and Validation AUC')
    axes[1, 0].legend()
    axes[1, 0].grid(True)
    
    # F1 Score
    axes[1, 1].plot(history['val_f1'], label='Val F1', marker='o', color='green')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('F1 Score')
    axes[1, 1].set_title('Validation F1 Score')
    axes[1, 1].legend()
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Training history plot saved to: {save_path}")


def plot_confusion_matrix(cm, save_path):
    """Plot confusion matrix"""
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['No Aneurysm', 'Aneurysm'],
                yticklabels=['No Aneurysm', 'Aneurysm'])
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix (Best Validation Epoch)')
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Confusion matrix saved to: {save_path}")


def train_single_modality(modality, config, num_epochs=50, batch_size=16, learning_rate=1e-4):
    """Train a single modality model"""
    
    print("=" * 80)
    print(f"TRAINING RESNET50 MODEL FOR {modality}")
    print("=" * 80)
    
    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(config.data.output_root, f"resnet50_{modality}_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)
    
    # Determine base directory for modality
    if modality == 'CTA':
        base_dir = config.data.preprocessed_cta_dir
    elif modality == 'MRA':
        base_dir = config.data.preprocessed_mra_dir
    else:  # MRI
        base_dir = config.data.preprocessed_mri_dir
    
    print(f"\nData directory: {base_dir}")
    print(f"Output directory: {output_dir}")
    
    # Load data splits
    print("\nLoading data splits...")
    if config.data.use_selected_dataset and os.path.exists(config.data.selected_dataset_csv):
        df = pd.read_csv(config.data.selected_dataset_csv)
        print(f"Loaded selected dataset: {len(df)} series")
    else:
        df = pd.read_csv(config.data.train_csv)
        print(f"Loaded full dataset: {len(df)} series")
    
    # Filter by modality
    if modality == 'MRI':
        # Include both T1 and T2 for MRI
        df_modality = df[df['Modality'].str.contains('MRI', case=False, na=False)].copy()
    else:
        df_modality = df[df['Modality'].str.upper() == modality].copy()
    
    print(f"Filtered {modality} data: {len(df_modality)} series")
    
    # Create train/val/test splits (70/15/15)
    from sklearn.model_selection import train_test_split
    
    train_df, temp_df = train_test_split(
        df_modality, test_size=0.3, random_state=config.data.random_seed,
        stratify=df_modality['Aneurysm Present']
    )
    
    val_df, test_df = train_test_split(
        temp_df, test_size=0.5, random_state=config.data.random_seed,
        stratify=temp_df['Aneurysm Present']
    )
    
    print(f"\nData splits:")
    print(f"  Train: {len(train_df)} ({train_df['Aneurysm Present'].sum()} positive)")
    print(f"  Val:   {len(val_df)} ({val_df['Aneurysm Present'].sum()} positive)")
    print(f"  Test:  {len(test_df)} ({test_df['Aneurysm Present'].sum()} positive)")
    
    # Create datasets
    train_dataset = AneurysmDataset(train_df, modality, base_dir, augment=True)
    val_dataset = AneurysmDataset(val_df, modality, base_dir, augment=False)
    test_dataset = AneurysmDataset(test_df, modality, base_dir, augment=False)
    
    # Create dataloaders
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, 
                             num_workers=4, pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, 
                           num_workers=4, pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, 
                            num_workers=4, pin_memory=True)
    
    # Initialize model
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\nUsing device: {device}")
    
    model = ResNet50_2_5D(num_classes=2, input_channels=7, pretrained=True)
    model = model.to(device)
    
    # Count parameters
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total parameters: {total_params:,}")
    print(f"Trainable parameters: {trainable_params:,}")
    
    # Loss and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)  # Increased from 1e-5
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs, eta_min=1e-7)
    
    # Mixed precision scaler
    from torch.amp import GradScaler
    scaler = GradScaler('cuda') if torch.cuda.is_available() else None
    
    # Training history
    history = {
        'train_loss': [], 'train_acc': [], 'train_auc': [],
        'val_loss': [], 'val_acc': [], 'val_auc': [], 'val_f1': [],
        'val_precision': [], 'val_recall': []
    }
    
    best_val_auc = 0.0
    best_epoch = 0
    patience = 15
    patience_counter = 0
    
    # Training loop
    print(f"\nStarting training for {num_epochs} epochs...")
    print("=" * 80)
    
    for epoch in range(num_epochs):
        print(f"\nEpoch {epoch+1}/{num_epochs}")
        print("-" * 40)
        
        # Train
        train_loss, train_acc, train_auc = train_epoch(
            model, train_loader, criterion, optimizer, device, scaler
        )
        
        # Validate
        val_metrics = validate(model, val_loader, criterion, device)
        
        # Update scheduler
        scheduler.step()
        
        # Record history
        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['train_auc'].append(train_auc)
        history['val_loss'].append(val_metrics['loss'])
        history['val_acc'].append(val_metrics['accuracy'])
        history['val_auc'].append(val_metrics['auc'])
        history['val_f1'].append(val_metrics['f1'])
        history['val_precision'].append(val_metrics['precision'])
        history['val_recall'].append(val_metrics['recall'])
        
        # Print metrics
        print(f"\nTrain Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f} | Train AUC: {train_auc:.4f}")
        print(f"Val Loss:   {val_metrics['loss']:.4f} | Val Acc:   {val_metrics['accuracy']:.4f} | Val AUC:   {val_metrics['auc']:.4f}")
        print(f"Val F1:     {val_metrics['f1']:.4f} | Val Precision: {val_metrics['precision']:.4f} | Val Recall: {val_metrics['recall']:.4f}")
        
        # Save best model
        if val_metrics['auc'] > best_val_auc:
            best_val_auc = val_metrics['auc']
            best_epoch = epoch + 1
            patience_counter = 0
            
            # Save model
            checkpoint_path = os.path.join(output_dir, f'best_model_{modality}.pth')
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_auc': best_val_auc,
                'val_metrics': val_metrics,
                'history': history
            }, checkpoint_path)
            
            print(f"\n✓ New best model saved! (AUC: {best_val_auc:.4f})")
            
            # Save confusion matrix for best epoch
            best_cm = val_metrics['confusion_matrix']
        else:
            patience_counter += 1
            print(f"\nNo improvement. Patience: {patience_counter}/{patience}")
        
        # Early stopping
        if patience_counter >= patience:
            print(f"\nEarly stopping triggered after {epoch+1} epochs")
            break
    
    # Save final training history
    print("\n" + "=" * 80)
    print("TRAINING COMPLETED")
    print("=" * 80)
    print(f"\nBest Validation AUC: {best_val_auc:.4f} (Epoch {best_epoch})")
    
    # Save training plots
    plot_path = os.path.join(output_dir, f'training_history_{modality}.png')
    plot_training_history(history, plot_path)
    
    cm_path = os.path.join(output_dir, f'confusion_matrix_{modality}.png')
    plot_confusion_matrix(best_cm, cm_path)
    
    # Save history as JSON
    history_path = os.path.join(output_dir, f'history_{modality}.json')
    with open(history_path, 'w') as f:
        json.dump(history, f, indent=2)
    print(f"Training history saved to: {history_path}")
    
    # Test on best model
    print("\n" + "=" * 80)
    print("EVALUATING ON TEST SET")
    print("=" * 80)
    
    # Load best model
    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    test_metrics = validate(model, test_loader, criterion, device)
    
    print(f"\nTest Results:")
    print(f"  Loss:      {test_metrics['loss']:.4f}")
    print(f"  Accuracy:  {test_metrics['accuracy']:.4f}")
    print(f"  Precision: {test_metrics['precision']:.4f}")
    print(f"  Recall:    {test_metrics['recall']:.4f}")
    print(f"  F1 Score:  {test_metrics['f1']:.4f}")
    print(f"  AUC:       {test_metrics['auc']:.4f}")
    
    # Save test confusion matrix
    test_cm_path = os.path.join(output_dir, f'test_confusion_matrix_{modality}.png')
    plot_confusion_matrix(test_metrics['confusion_matrix'], test_cm_path)
    
    # Save test results
    test_results = {
        'modality': modality,
        'test_loss': float(test_metrics['loss']),
        'test_accuracy': float(test_metrics['accuracy']),
        'test_precision': float(test_metrics['precision']),
        'test_recall': float(test_metrics['recall']),
        'test_f1': float(test_metrics['f1']),
        'test_auc': float(test_metrics['auc']),
        'best_val_auc': float(best_val_auc),
        'best_epoch': best_epoch,
        'total_epochs': epoch + 1
    }
    
    results_path = os.path.join(output_dir, f'test_results_{modality}.json')
    with open(results_path, 'w') as f:
        json.dump(test_results, f, indent=2)
    print(f"\nTest results saved to: {results_path}")
    
    print("\n" + "=" * 80)
    print(f"All outputs saved to: {output_dir}")
    print("=" * 80)
    
    return output_dir, test_results


def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Train ResNet50 for Aneurysm Detection')
    parser.add_argument('--modality', type=str, choices=['CTA', 'MRA', 'MRI'], 
                       help='Modality to train (CTA, MRA, or MRI)')
    parser.add_argument('--all', action='store_true', 
                       help='Train all three modalities sequentially')
    parser.add_argument('--epochs', type=int, default=50, 
                       help='Number of training epochs (default: 50)')
    parser.add_argument('--batch_size', type=int, default=16, 
                       help='Batch size (default: 16)')
    parser.add_argument('--lr', type=float, default=1e-4, 
                       help='Learning rate (default: 1e-4)')
    
    args = parser.parse_args()
    
    # Load configuration
    config = Config()
    
    # Determine which modalities to train
    if args.all:
        modalities = ['CTA', 'MRA', 'MRI']
    elif args.modality:
        modalities = [args.modality]
    else:
        print("Error: Please specify --modality or --all")
        return
    
    # Train each modality
    all_results = {}
    for modality in modalities:
        output_dir, results = train_single_modality(
            modality, config, 
            num_epochs=args.epochs,
            batch_size=args.batch_size,
            learning_rate=args.lr
        )
        all_results[modality] = results
        print("\n" + "=" * 80)
        print("\n")
    
    # Summary if training all modalities
    if len(modalities) > 1:
        print("=" * 80)
        print("SUMMARY OF ALL MODALITIES")
        print("=" * 80)
        for modality, results in all_results.items():
            print(f"\n{modality}:")
            print(f"  Test AUC: {results['test_auc']:.4f}")
            print(f"  Test F1:  {results['test_f1']:.4f}")
            print(f"  Test Acc: {results['test_accuracy']:.4f}")


if __name__ == "__main__":
    main()
