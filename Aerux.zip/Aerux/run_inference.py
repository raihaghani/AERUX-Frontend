"""
Quick Inference Runner - Automatically finds latest fusion model and runs inference

Usage:
    python run_inference.py
"""

import os
import glob
from datetime import datetime

# Find the latest fusion model
print("=" * 80)
print("SEARCHING FOR TRAINED FUSION MODEL")
print("=" * 80)

pattern = "E:/Education/Aerux_Final/outputs/fusion_*/best_fusion_model.pth"
checkpoints = glob.glob(pattern)

if not checkpoints:
    print(f"\nERROR: No fusion model found!")
    print(f"Pattern searched: {pattern}")
    print("\nPlease train a fusion model first:")
    print("  python run_fusion_training.py")
    exit(1)

# Sort by modification time, most recent first
checkpoints.sort(key=os.path.getmtime, reverse=True)
latest_checkpoint = checkpoints[0]

# Get modification time
mod_time = os.path.getmtime(latest_checkpoint)
mod_date = datetime.fromtimestamp(mod_time).strftime('%Y-%m-%d %H:%M:%S')

print(f"\n[OK] Found fusion model: {os.path.dirname(latest_checkpoint)}")
print(f"     Trained: {mod_date}")

if len(checkpoints) > 1:
    print(f"\nNote: Found {len(checkpoints)} fusion models, using most recent")

# Build the command
command = f'python inference_fusion.py --fusion_model "{latest_checkpoint}" --batch_size 16'

print("\n" + "=" * 80)
print("RUNNING INFERENCE ON TEST SET")
print("=" * 80)
print(f"\nCommand: {command}\n")
print("=" * 80)

# Execute
os.system(command)
